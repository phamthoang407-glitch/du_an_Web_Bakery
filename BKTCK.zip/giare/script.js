/* giare.vn - xử lý: sản phẩm, tài khoản, giỏ hàng, đơn hàng, thống kê, cài đặt cửa hàng */
const TYPES={
 ao_thun:{n:"Áo thun",d:'<path d="M70 30 L30 50 L12 100 L45 112 L55 85 L55 205 L145 205 L145 85 L155 112 L188 100 L170 50 L130 30 Q100 58 70 30Z"/>'},
 so_mi:{n:"Áo sơ mi",d:'<path d="M70 28 L28 48 L8 150 L42 156 L52 100 L52 208 L148 208 L148 100 L158 156 L192 150 L172 48 L130 28 L100 60Z"/><path d="M100 60 V208" class="ln"/>'},
 khoac:{n:"Áo khoác",d:'<path d="M72 26 L26 46 L6 160 L42 166 L52 110 L52 210 L148 210 L148 110 L158 166 L194 160 L174 46 L128 26 Q100 44 72 26Z"/><path d="M100 40 V210" class="ln"/>'},
 quan:{n:"Quần dài",d:'<path d="M52 20 H148 L156 215 H108 L100 90 L92 215 H44Z"/>'},
 vay:{n:"Váy",d:'<path d="M72 20 H128 L136 70 L176 215 H24 L64 70Z"/>'}
};
const DEF=[
 {id:1,name:"Áo thun cổ tròn",type:"ao_thun",color:"#2f6f5e",img:"ao-thun.jpg",price:189000,cost:90000,sizes:"S, M, L, XL"},
 {id:2,name:"Sơ mi linen",type:"so_mi",color:"#c9b79c",img:"so-mi.png",price:329000,cost:170000,sizes:"M, L"},
 {id:3,name:"Quần ống suông",type:"quan",color:"#3b4a6b",img:"quan.jpg",price:399000,cost:210000,sizes:"S, M, L"},
 {id:4,name:"Váy xòe midi",type:"vay",color:"#b5483a",img:"vay.jpg",price:459000,cost:230000,sizes:"S, M"},
 {id:5,name:"Áo khoác gió",type:"khoac",color:"#d9a441",img:"ao-khoac.jpg",price:529000,cost:280000,sizes:"M, L, XL"}
];
let curImg="",cart=[],orders=[],items=[],users=[],me=null,view="shop",filter="all",editId=null,mode="login";
const $=s=>document.querySelector(s);
const KEY="xm_items_v1",USERS="xm_users_v1",SESS="xm_sess_v1",ORD="xm_orders_v1";
function load(){try{const r=localStorage.getItem(KEY);items=r?JSON.parse(r):DEF.slice()}catch(e){items=DEF.slice()}
 try{if(!localStorage.getItem("xm_imgmig_v1")){const M={1:"ao-thun.jpg",2:"so-mi.png",3:"quan.jpg",4:"vay.jpg",5:"ao-khoac.jpg"};items.forEach(i=>{if(M[i.id]&&!i.img)i.img=M[i.id]});localStorage.setItem("xm_imgmig_v1","1");persist()}}catch(e){}
 try{users=JSON.parse(localStorage.getItem(USERS)||"[]");const s=localStorage.getItem(SESS);me=users.find(x=>x.u===s)||null}catch(e){users=[];me=null}}
function canEdit(){return !!me&&me.role==="business"}
function loadOrders(){try{orders=JSON.parse(localStorage.getItem(ORD)||"[]")}catch(e){orders=[]}}
function saveOrders(){try{localStorage.setItem(ORD,JSON.stringify(orders))}catch(e){}}
function loadCart(){try{cart=me?JSON.parse(localStorage.getItem("xm_cart_"+me.u)||"[]"):[]}catch(e){cart=[]}}
function saveCart(){try{if(me)localStorage.setItem("xm_cart_"+me.u,JSON.stringify(cart))}catch(e){}}
function addCart(id){
 if(!me){openAuth("login");return}
 const el=document.getElementById("sz"+id);if(!el)return;
 const size=el.value,l=cart.find(x=>x.id===id&&x.size===size);
 if(l)l.qty++;else cart.push({id,size,qty:1});
 saveCart();render();
}
function cartLines(){return cart.map(l=>({...l,it:items.find(i=>i.id===l.id)}))}
function openCart(){
 cart=cart.filter(l=>items.some(i=>i.id===l.id));saveCart();
 const ls=cartLines(),tot=ls.reduce((s,l)=>s+unit(l.it)*l.qty,0);
 $("#cartBody").innerHTML=ls.length?ls.map((l,k)=>`<div class="cl"><div class="th">${pic(l.it)}</div><div><b>${esc(l.it.name)}</b><br><small>Size ${esc(l.size)} – ${money(unit(l.it))}</small></div><div><button class="btn sm" data-q="-1" data-k="${k}" aria-label="Giảm">−</button> ${l.qty} <button class="btn sm" data-q="1" data-k="${k}" aria-label="Tăng">+</button></div></div>`).join("")+`<p><b>Tổng: ${money(tot)}</b></p>`:'<div class="empty">Giỏ hàng trống. Chọn size và bấm “Thêm vào giỏ” ở cửa hàng.</div>';
 $("#cerr").textContent="";$("#buy").hidden=!ls.length;$("#shipWrap").hidden=!ls.length;
 if(!$("#dlgCart").open)$("#dlgCart").showModal();
 render();
}
function statsHtml(){
 loadOrders();
 const done=orders.filter(o=>o.status==="Đã xác nhận"),wait=orders.filter(o=>o.status!=="Đã xác nhận");
 const sum=(a,f)=>a.reduce((s,o)=>s+f(o),0);
 const rev=sum(done,o=>o.total),cost=sum(done,o=>o.lines.reduce((s,l)=>s+(l.cost||0)*l.qty,0));
 const profit=rev-cost,margin=rev?Math.round(profit/rev*100):0;
 const qty=sum(done,o=>o.lines.reduce((s,l)=>s+l.qty,0)),waitVal=sum(wait,o=>o.total);
 const by={};
 done.forEach(o=>o.lines.forEach(l=>{const b=by[l.name]||(by[l.name]={q:0,r:0,c:0});b.q+=l.qty;b.r+=l.price*l.qty;b.c+=(l.cost||0)*l.qty}));
 const rows=Object.entries(by).sort((a,b)=>(b[1].r-b[1].c)-(a[1].r-a[1].c));
 const max=Math.max(1,...rows.map(r=>Math.abs(r[1].r-r[1].c)));
 const kp=(t,v,s)=>`<div class="kpi"><small>${t}</small><b>${v}</b><small>${s}</small></div>`;
 const noCost=items.filter(i=>i.scope!=="design"&&!(i.cost>0)).length;
 return `<div style="grid-column:1/-1"><div class="kpis">${kp("Doanh thu",money(rev),done.length+" đơn đã xác nhận")+kp("Giá vốn",money(cost),qty+" sản phẩm đã bán")+kp("Lãi",money(profit),"Biên lãi "+margin+"%")+kp("Chờ xác nhận",wait.length+" đơn",money(waitVal))}</div>${noCost?`<p class="err">${noCost} sản phẩm chưa nhập giá vốn nên lãi có thể cao hơn thực tế. Bấm Sửa ở cửa hàng để nhập.</p>`:""}<h3>Lãi theo sản phẩm</h3>${rows.length?rows.map(([n,b])=>{const p=b.r-b.c;return `<div class="brow"><span>${esc(n)}</span><div class="bar2"><i style="width:${Math.max(2,Math.abs(p)/max*100)}%;background:${p<0?"#b3261e":"var(--acc)"}"></i></div><span>${b.q} cái – lãi ${money(p)}</span></div>`}).join(""):'<div class="empty">Chưa có đơn nào được xác nhận. Doanh số được tính khi bạn bấm “Xác nhận đơn”.</div>'}</div>`
}
function ordersHtml(){
 loadOrders();
 const biz=!!me&&me.role==="business";
 const list=orders.filter(o=>biz||o.buyer===me.u).slice().reverse();
 if(!list.length)return '<div class="empty" style="grid-column:1/-1">'+(biz?"Chưa có đơn hàng nào.":"Bạn chưa đặt đơn nào.")+'</div>';
 return list.map(o=>`<div class="ord" style="grid-column:1/-1"><b>Đơn ${esc(o.date)}</b> – ${esc(o.status)}${biz?` – ${esc(o.buyerName)}, ${esc(o.phone)}, ${esc(o.addr)}`:""}<br>${o.lines.map(l=>`${esc(l.name)} (${esc(l.size)}) x${l.qty}`).join("; ")}<br><b>${money(o.total)}</b>${biz&&o.status==="Chờ xác nhận"?` <button class="btn sm" data-o="${o.id}">Xác nhận đơn</button>`:""}</div>`).join("")
}
function persist(){try{localStorage.setItem(KEY,JSON.stringify(items))}catch(e){}}
function esc(s){return String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]))}
function shade(h,a){const n=parseInt(h.slice(1),16);let r=n>>16,g=n>>8&255,b=n&255;const f=v=>Math.max(0,Math.min(255,v+a));return"#"+((1<<24)+(f(r)<<16)+(f(g)<<8)+f(b)).toString(16).slice(1)}
function garment(type,color){const t=TYPES[type]||TYPES.ao_thun;
 return `<svg viewBox="0 0 200 230" role="img" aria-label="${t.n}"><g fill="${color}" stroke="${shade(color,-40)}" stroke-width="2" stroke-linejoin="round">${t.d.replace(/class="ln"/g,'fill="none" stroke="'+shade(color,-50)+'"')}</g></svg>`}
function pic(i){return i.img?`<img src="${esc(i.img)}" alt="${esc(i.name)}" data-t="${i.type}" data-c="${i.color}">`:garment(i.type,i.color)}
function unit(i){return i.sale>0?Math.round(i.price*(100-i.sale)/100/1000)*1000:i.price}
function money(v){return Number(v).toLocaleString("vi-VN")+" ₫"}
function render(){
 renderFooter();
 $("#who").textContent=me?`${me.name} (${me.role==="business"?"Doanh nghiệp":"Khách hàng"})`:"";
 $("#login").textContent=me?"Đăng xuất":"Đăng nhập";
 $("#reg").hidden=!!me;
 if(!me)view="shop";
 const biz=!!me&&me.role==="business";
 $("#cartBtn").hidden=!me||biz;
 $("#cartBtn").textContent="Giỏ hàng ("+cart.reduce((s,l)=>s+l.qty,0)+")";
 $("#filters").hidden=view==="orders"||view==="stats";
 const vw=$("#views");vw.hidden=!me;
 vw.innerHTML=[["shop","Cửa hàng"],["orders",biz?"Đơn khách đặt":"Đơn của tôi"],...(biz?[["stats","Doanh số & lãi"]]:[])].map(([k,n])=>`<button class="chip" data-v="${k}" aria-pressed="${view===k}">${n}</button>`).join("");
 $("#addWrap").hidden=!(biz&&view==="shop");
 const f=$("#filters");f.innerHTML="";
 [["all","Tất cả"],...Object.entries(TYPES).map(([k,v])=>[k,v.n])].forEach(([k,n])=>{
  const b=document.createElement("button");b.className="chip";b.textContent=n;b.setAttribute("aria-pressed",filter===k);
  b.onclick=()=>{filter=k;render()};f.appendChild(b)});
 if(view==="stats"&&biz){$("#grid").innerHTML=statsHtml();return}
 if(view==="orders"){$("#grid").innerHTML=ordersHtml();return}
 const list=items.filter(i=>(filter==="all"||i.type===filter)&&i.scope!=="design");
 $("#grid").innerHTML=list.length?list.map(i=>`<article class="item">${pic(i)}
  <h3>${esc(i.name)}</h3><p class="price">${i.sale>0?`<s style="color:var(--mut);font-weight:400">${money(i.price)}</s> ${money(unit(i))} <span class="tag">-${i.sale}%</span>`:money(i.price)}</p><p>Size: ${esc(i.sizes)}</p>${biz?"":`<div class="acts"><select id="sz${i.id}" aria-label="Chọn size">${i.sizes.split(",").map(s=>s.trim()).filter(Boolean).map(s=>`<option>${esc(s)}</option>`).join("")}</select><button class="btn pri sm" data-c="${i.id}">Thêm vào giỏ</button></div>`}
  ${canEdit(i)?`<div class="acts"><button class="btn sm" data-e="${i.id}">Sửa</button><button class="btn sm" data-d="${i.id}">Xóa</button></div>`:""}</article>`).join("")
  :'<div class="empty">Chưa có sản phẩm nào trong mục này.</div>';
}
$("#grid").addEventListener("click",e=>{
 const ed=e.target.dataset.e,de=e.target.dataset.d;
 if(ed)openItem(+ed);
 if(e.target.dataset.c)addCart(+e.target.dataset.c);
 if(e.target.dataset.o){loadOrders();const o=orders.find(x=>x.id===+e.target.dataset.o);if(o){o.status="Đã xác nhận";saveOrders();render()}}
 if(de&&confirm("Xóa sản phẩm này?")){items=items.filter(i=>i.id!==+de);persist();render()}
});
$("#fType").innerHTML=Object.entries(TYPES).map(([k,v])=>`<option value="${k}">${v.n}</option>`).join("");
function prev(){$("#prev").innerHTML=curImg?`<img src="${esc(curImg)}" alt="Ảnh sản phẩm" style="width:100%;max-height:200px;object-fit:contain">`:garment($("#fType").value,$("#fColor").value)}
["#fType","#fColor"].forEach(s=>$(s).addEventListener("input",prev));
$("#fImg").addEventListener("change",e=>{const f=e.target.files[0];if(!f)return;
 const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{
  const k=Math.min(1,600/Math.max(im.width,im.height)),c=document.createElement("canvas");
  c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);
  const x=c.getContext("2d");x.fillStyle="#fff";x.fillRect(0,0,c.width,c.height);x.drawImage(im,0,0,c.width,c.height);
  curImg=c.toDataURL("image/jpeg",.85);$("#fNoImg").checked=false;prev()};
  im.onerror=()=>{$("#ierr").textContent="Không đọc được ảnh này."};im.src=r.result};
 r.readAsDataURL(f)});
$("#fNoImg").addEventListener("change",e=>{if(e.target.checked){curImg="";$("#fImg").value=""}prev()});
document.addEventListener("error",e=>{const im=e.target;if(im.tagName==="IMG"&&im.dataset.t)im.outerHTML=garment(im.dataset.t,im.dataset.c)},true);
function openItem(id){
 editId=id||null;const it=items.find(i=>i.id===id);
 $("#dTitle").textContent=it?"Sửa sản phẩm":"Thêm sản phẩm";
 $("#fName").value=it?it.name:"";$("#fType").value=it?it.type:"ao_thun";
 $("#fColor").value=it?it.color:"#0f5c5c";$("#fPrice").value=it?it.price:"";$("#fCost").value=it&&it.cost!=null?it.cost:"";$("#fSale").value=it&&it.sale?it.sale:"";
 $("#fSize").value=it?it.sizes:"S, M, L";$("#ierr").textContent="";curImg=it&&it.img?it.img:"";$("#fImg").value="";$("#fNoImg").checked=false;prev();$("#dlgItem").showModal();
}
$("#add").onclick=()=>openItem(null);
$("#save").onclick=()=>{
 const name=$("#fName").value.trim(),price=Number($("#fPrice").value);
 if(!name){$("#ierr").textContent="Nhập tên sản phẩm.";return}
 if(!(price>=0)||$("#fPrice").value===""){$("#ierr").textContent="Nhập giá hợp lệ.";return}
 const d={name,type:$("#fType").value,color:$("#fColor").value,price,cost:Number($("#fCost").value)||0,sale:Math.min(90,Math.max(0,Math.round(Number($("#fSale").value)||0)))||undefined,img:curImg||undefined,sizes:$("#fSize").value.trim()||"Free size"};
 if(editId){items=items.map(i=>i.id===editId?{...i,...d}:i)}
 else{items.push({id:Date.now(),owner:me.u,scope:me.role==="business"?"shop":"design",...d})}
 persist();$("#dlgItem").close();render();
};
async function hash(s){try{const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(s));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("")}catch(e){return btoa(unescape(encodeURIComponent(s)))}}
function setMode(m){mode=m;const r=m==="register";$("#aTitle").textContent=r?"Tạo tài khoản":"Đăng nhập";$("#roleWrap").hidden=!r;$("#nameWrap").hidden=!r;$("#doAuth").textContent=r?"Tạo tài khoản":"Đăng nhập";$("#swap").textContent=r?"Đã có tài khoản? Đăng nhập":"Chưa có tài khoản? Tạo tài khoản";$("#lerr").textContent="";$("#p").autocomplete=r?"new-password":"current-password"}
function openAuth(m){setMode(m);$("#p").value="";$("#dlgLogin").showModal()}
$("#login").onclick=()=>{if(me){me=null;cart=[];view="shop";try{localStorage.removeItem(SESS)}catch(e){}render();return}openAuth("login")};
$("#reg").onclick=()=>openAuth("register");
$("#cartBtn").onclick=openCart;
$("#cartBody").addEventListener("click",e=>{const q=e.target.dataset.q;if(!q)return;const k=+e.target.dataset.k,l=cart[k];if(!l)return;l.qty+=+q;if(l.qty<=0)cart.splice(k,1);saveCart();openCart()});
$("#buy").onclick=()=>{
 const ls=cartLines(),a=$("#addr").value.trim(),ph=$("#phone").value.trim();
 if(!ls.length)return;
 if(!a||!ph){$("#cerr").textContent="Nhập địa chỉ và số điện thoại nhận hàng.";return}
 loadOrders();
 orders.push({id:Date.now(),buyer:me.u,buyerName:me.name,addr:a,phone:ph,date:new Date().toLocaleString("vi-VN"),status:"Chờ xác nhận",lines:ls.map(l=>({name:l.it.name,size:l.size,qty:l.qty,price:unit(l.it),cost:l.it.cost||0})),total:ls.reduce((s,l)=>s+unit(l.it)*l.qty,0)});
 saveOrders();cart=[];saveCart();$("#dlgCart").close();view="orders";render();
};
$("#swap").onclick=()=>setMode(mode==="login"?"register":"login");
$("#views").addEventListener("click",e=>{if(e.target.dataset.v){view=e.target.dataset.v;render()}});
$("#doAuth").onclick=async()=>{
 const u=$("#u").value.trim().toLowerCase(),p=$("#p").value;
 if(!/^[a-z0-9_]{3,30}$/.test(u)){$("#lerr").textContent="Tên đăng nhập 3–30 ký tự: chữ thường không dấu, số, dấu gạch dưới.";return}
 if(p.length<6){$("#lerr").textContent="Mật khẩu tối thiểu 6 ký tự.";return}
 const h=await hash(p);
 if(mode==="register"){
  if(users.some(x=>x.u===u)){$("#lerr").textContent="Tên đăng nhập đã tồn tại.";return}
  me={u,name:$("#dn").value.trim()||u,role:$("#role").value,h};users.push(me);
  try{localStorage.setItem(USERS,JSON.stringify(users))}catch(e){}
 }else{
  const f=users.find(x=>x.u===u&&x.h===h);
  if(!f){$("#lerr").textContent="Sai tên đăng nhập hoặc mật khẩu.";return}
  me=f;
 }
 try{localStorage.setItem(SESS,me.u)}catch(e){}
 loadCart();
 $("#dlgLogin").close();render();
};
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>b.closest("dialog").close());
const SHOP="xm_shop_v1",DEFPOL="(Nội dung mẫu, doanh nghiệp chỉnh lại cho đúng cửa hàng.)\n- Đổi trả trong 7 ngày kể từ khi nhận hàng.\n- Sản phẩm còn nguyên tem mác, chưa giặt, chưa qua sử dụng.\n- Đổi size hoặc mẫu khác nếu còn hàng.\n- Sản phẩm lỗi do nhà sản xuất được đổi mới hoặc hoàn tiền.\n- Gọi số điện thoại của cửa hàng trước khi gửi hàng về.";
let shop={phone:"",policy:DEFPOL};
function loadShop(){try{const r=JSON.parse(localStorage.getItem(SHOP)||"null");if(r&&typeof r==="object")shop={phone:String(r.phone||""),policy:String(r.policy||DEFPOL)}}catch(e){}}
function renderFooter(){
 const biz=!!me&&me.role==="business";
 $("#contact").textContent=shop.phone?"Hotline: "+shop.phone:(biz?"Chưa có số điện thoại. Bấm Cài đặt cửa hàng để thêm.":"");
 $("#shopBtn").hidden=!biz;
}
$("#policyBtn").onclick=()=>{$("#polText").textContent=shop.policy;$("#polTel").textContent=shop.phone?"Hotline: "+shop.phone:"";$("#dlgPolicy").showModal()};
$("#shopBtn").onclick=()=>{$("#shPhone").value=shop.phone;$("#shPol").value=shop.policy;$("#shErr").textContent="";$("#dlgShop").showModal()};
$("#shSave").onclick=()=>{
 const ph=$("#shPhone").value.trim();
 if(ph&&!/^[0-9+\s.()-]{8,20}$/.test(ph)){$("#shErr").textContent="Số điện thoại chưa đúng, chỉ dùng số, dấu cách, dấu + và dấu chấm.";return}
 shop={phone:ph,policy:$("#shPol").value.trim()||DEFPOL};
 try{localStorage.setItem(SHOP,JSON.stringify(shop))}catch(e){}
 $("#dlgShop").close();render();
};
load();loadShop();loadCart();render();
